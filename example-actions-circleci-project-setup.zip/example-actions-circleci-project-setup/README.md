# How to Start

1. Fork this repo.
2. Set `NEXPLOIT_TOKEN` and `REPEATER` secrets in your repo settings.
3. Run a CI job in Actions.
4. Go to Nexploit app and check if a scan started.
